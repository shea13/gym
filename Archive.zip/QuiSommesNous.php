<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xml:lang="fr" xmlns="http://www.w3.org/1999/xhtml" lang="fr">
<head>
<title>CLUB GYMNIQUE FOSSEEN</title>
<meta name="Description" content="Site du club de gymnastique de Fos Sur Mer.">
<meta name="keywords" content="Gymnastique, GR, Gymnastique, Artistique, Rythmique, Aérobic, Hip Hop, Step, Modern dance">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="-1">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">


<link rel="stylesheet" type="text/css" media="all" href="css/style.css">
<body id="bodyHome" style="background: url('/images/fond.jpg') no-repeat scroll center top white;">
<div id="csall">
<?php include("menu.php");?>
  <div id="csleft">


    <hr>
    <div class="csclear"></div>
    <div id="imgGymMiddle">
      <div class="onlineeditor">
        <div><?php include("inc/imageEntete.php");?></div>
      </div>
    </div>
        <div title="clug gymnique fosséen">
    </div>
    <h1>Club Gymnique Fosséen</h1>
    <hr>
    <div id="lignesDiv">
      
      
      <hr>
      <div> <br/><br/>Le Club de Gymnastique Fosséen a été créé par Pierre Klauser à Fos sur Mer, le 5 janvier 1966. <br />
        Son but est la pratique et la promotion des gymnastiques de loisir pour tous, de la forme et de la compétition.<br />
Il est affilié à la Fédération Française de Gymnastique et à la Fédération Française d'Education Physique et de Gymnastique Volontaire<br />
Il propose de nombreuses activités aux jeunes et aux moins jeunes.<br />
En 2010 il compte 460 adhérents.<br />
Des animateurs compétents vous accueilleront avec le sourire dans leurs <a href="cours.php">cours</a> de :<br />
<b><i>Renforcement Musculaire</i></b>, <b><i>LIA, Gymnastique
              Dynamique, Latino-Training, HIP-HOP,  Step, Stretching, Zumba, Gymnastique
              détente, Gymnastique Rythmique, </i></b><b><i>Eveil Gymnique</i></b>, <b><i>Baby Hip.Hop</i></b>, <b><i>Modern’Dance</i></b> <b><i>, Gymnastique Parents-Bébé</i></b><br />
<br />
      </div>
      
      <div class="csclear"></div>
    </div>
    
    <hr>
    
    
  </div>
  <hr>
  <?php include("divr.php");?>
  <div class="csclear"></div>
</div>
<!-- fin csall -->
<hr>
<?php 
include("inc/footer.php");
?>
</body>
</html>
