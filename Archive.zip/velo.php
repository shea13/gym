<?php 
header("Location: veloInside.php?t=".time());
exit;
?>