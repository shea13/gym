<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xml:lang="fr" xmlns="http://www.w3.org/1999/xhtml" lang="fr">
<head>
<title>CLUB GYMNIQUE FOSSEEN</title>
<meta name="Description" content="Site du club de gymnastique de Fos Sur Mer.">
<meta name="keywords" content="Gymnastique, GR, Gymnastique, Artistique, Rythmique, Aérobic, Hip Hop, Step, Modern dance">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="-1">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">


<link rel="stylesheet" type="text/css" media="all" href="css/style.css">

<link rel="stylesheet" type="text/css" media="screen" href="css/reset.css" />
<link rel="stylesheet" type="text/css" media="screen" href="css/960.css" />
<link rel="stylesheet" type="text/css" media="screen" href="css/main.css" />
<script type="text/javascript" src="js/jquery-1.4.4.min.js"></script>
<script type="text/javascript" src="js/demo.js"></script>
</head>
<body id="bodyHome" style="background: url('/images/fond.jpg') no-repeat scroll center top white;">
<div id="csall">
<?php include("menu.php");?>
  <div id="csleft">
    <div title="clug gymnique fosséen">
    </div>
    <hr>
    <div class="csclear"></div>
    <div id="imgGymMiddle">
      <div class="onlineeditor">
        <div><?php include("inc/imageEntete.php");?></div>
      </div>
    </div>
    <hr>
    <div id="lignesDiv">
      
      
      <hr>
        <div class="grid_6 prefix_1 suffix_1" id="gallery">
          <div id="pictures">
						<?php $dim = ' height="400" width="500" ';?>
                        <img src="images/picture2.png" alt="" />
                        <img src="2010/gymnastique_fos1.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos2.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos3.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos4.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos5.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos6.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos7.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos8.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos9.jpg" alt="" <? print $dim;?>/>
                        
                         <img src="2010/gymnastique_fos10.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos11.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos12.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos13.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos14.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos15.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos16.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos17.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos18.jpg" alt="" <? print $dim;?>/>
                        
                         <img src="2010/gymnastique_fos19.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos20.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos21.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos22.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos23.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos24.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos25.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos26.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos27.jpg" alt="" <? print $dim;?>/>
                        
                         <img src="2010/gymnastique_fos28.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos29.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos30.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos31.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos32.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos33.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos34.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos35.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos36.jpg" alt="" <? print $dim;?>/>
                        
                         <img src="2010/gymnastique_fos37.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos38.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos39.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos40.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos41.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos42.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos43.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos44.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos45.jpg" alt="" <? print $dim;?>/>
                        
                         <img src="2010/gymnastique_fos46.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos47.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos48.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos49.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos50.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos51.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos52.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos53.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos54.jpg" alt="" <? print $dim;?>/>
                        
                         <img src="2010/gymnastique_fos55.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos56.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos57.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos58.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos59.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos60.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos61.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos62.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos63.jpg" alt="" <? print $dim;?>/>
                        
                         <img src="2010/gymnastique_fos64.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos65.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos66.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos67.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos68.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos69.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos70.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos71.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos72.jpg" alt="" <? print $dim;?>/>
                        
                         <img src="2010/gymnastique_fos73.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos74.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos75.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos76.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos77.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos78.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos79.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos80.jpg" alt="" <? print $dim;?>/>
                         <img src="2010/gymnastique_fos81.jpg" alt="" <? print $dim;?>/>
                        
                         <img src="2010/gymnastique_fos82.jpg" alt="" <? print $dim;?>/>
                         <img src="images/picture1.png" alt="" />
                        <img src="images/picture4.png" alt="" />
                        <img src="images/picture3.png" alt="" />
                        <img src="images/picture5.png" alt="" />
          </div>
           <div  style="height:10">
          <div class="suivante" style="height:10">
          <div class="grid_3 alpha" id="prev">
            <a href="#previous"> Photo précédente</a>
          </div>
          <div class="grid_3 omega" id="next">
            <a href="#next">Photo suivante </a>
          </div> </div>
          <div class="csclear"></div>
        </div>
          
        </div>
      
      <div class="csclear"></div>
    </div>
    
    <hr>
    
    
  </div>
  <hr>
  <?php include("divr.php");?>
  <div class="csclear"></div>
</div>
<!-- fin csall -->
<hr>
<?php 
include("inc/footer.php");
?>
</body>
</html>
