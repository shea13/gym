<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>CLUB GYMNIQUE FOSSEEN</title>
<meta name="Description" content="Site du club de gymnastique de Fos Sur Mer." />
<meta http-equiv="Pragma" content="no-cache" />
<meta http-equiv="Expires" content="-1" />
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" type="text/css" media="all" href="css/style.css" />
<style type="text/css">
<!--
.Style1 {
	font-family: "Times New Roman";
	font-size: 9pt;
}
-->
</style>
<script type="text/javascript" src="js/scriptaculous-js-1.8.3/lib/prototype.js"></script>
	<script type="text/javascript" src="js/scriptaculous-js-1.8.3/src/scriptaculous.js"></script>
	<script type="text/javascript">
	var cours1Visible = true;
	var cours2Visible = false;
	var cours3Visible = false;
	
	function cours(id)
	{ 
		options = { percent: 100 };
		switch(id)
		{
			case "cours1":
				
					if(cours2Visible)
					{
						//$('cours2').fade({ duration: 3.0, from: 0, to: 1 });
						new Effect.toggle('cours2', 'blind', { duration: 0.3 });
					}
					if(cours3Visible)
					{
						//$('cours3').fade({ duration: 3.0, from: 0, to: 1 });
						new Effect.toggle('cours3', 'blind', { duration: 0.3 });
					}

					if(!cours1Visible)
					{
						new Effect.toggle('cours1', 'blind', { duration: 0.3 });
					}
					
					cours1Visible = true;
				 	cours2Visible = false;
				 	cours3Visible = false;
					
				break;
			case "cours2":
					if(cours1Visible)
					{
						//Effect.Shrink('cours1');
						new Effect.toggle('cours1', 'blind', { duration: 0.3 });
					}
					if(cours3Visible)
					{
						//Effect.Shrink('cours3');
						new Effect.toggle('cours3', 'blind', { duration: 0.3 });
					}
					
					if(!cours2Visible)
					{
						new Effect.toggle('cours2', 'blind', { duration: 0.3 });
					}
					
					cours1Visible = false;
				 	cours2Visible = true;
				 	cours3Visible = false;
				break;;
			case "cours3":
			
					if(cours1Visible)
					{
						//Effect.Puff('cours1', { duration: 3 });
						new Effect.toggle('cours1', 'blind', { duration: 0.3 });
					}
					if(cours2Visible)
					{
						//Effect.Puff('cours2', { duration: 3 });
						new Effect.toggle('cours2', 'blind', { duration: 0.3 });
					}
					
					if(!cours3Visible)
					{
						new Effect.toggle('cours3', 'blind', { duration: 0.3 });
					}
					
					cours1Visible = false;
				 	cours2Visible = false;
				 	cours3Visible = true;
					
				break;
		}
		
	}
	</script>
</head>
<body bgcolor="#FFFFFF" id="bodyHome" style="background: url('/images/fond.jpg') no-repeat scroll center top white;">
<div id="csall">
<?php include("menu.php");?>
  <div id="csleft">    <hr />
    <div class="csclear"></div>
    <div id="imgGymMiddle">
      <div class="onlineeditor"><?php include("inc/imageEntete.php");?></div>
    </div>

    
    <hr/>
    
<br/>
    <div id="lignesDiv">
	  
<hr />
	  
      <table class="sousmenu">
      	<tr >
        	<td><a href="javascript:cours('cours1')">Cours adultes 2011-2012</a></td>
            <td><a href="javascript:cours('cours2')">Cours enfants,jeunes et ado 2011-2012</a></td>
            <td><a href="javascript:cours('cours3')">Cours GR compétition 2011-2012</a></td>
      		</tr>
          </table>
      <!--  TABLE 1 -->
      <div id = "cours1">
      <div align="center">
        <p><b><i><span style='font-size: 14pt; font-family: &quot;Times New Roman&quot;'>1 COTISATION ANNUELLE = 15h COURS ADULTES 2011-2012</span></i></b></p>
        <p><b><i></span><span class="Style1">PRATIQUE AU CHOIX ET SANS LIMITATION</span></i></b> </p>
      </div>
      <table width="320" border="0" align="center" class="cours">
        <tr>
          <td width="20" valign="top"><p class="MsoNormal"><b><i>L</i></b></p>
            <p class="MsoNormal"><b><i>U</i></b></p>
            <p class="MsoNormal"><b><i>N</i></b></p>
            <p class="MsoNormal"><b><i>D</i></b></p>
            <p class="MsoNormal"><b><i>I</i></b></p></td>
          <td width="97" valign="top"><p class="MsoNormal"><b><i>MPT.JAS GOUIN</i></b></p>
            <p class="MsoNormal"><b><i>Salle Polyvalente</i></b></p>
            <p class="MsoNormal"><b><i>&nbsp;&nbsp;&nbsp; 10h&nbsp; à&nbsp; 11h</i></b></p>
            <p class="MsoNormal"><b><i>Renf.Musculaire</i></b></p>
            <p class="MsoNormal"><b><i>&nbsp;&nbsp;&nbsp; NATHALIE</i></b></p></td>
          <td width="108" valign="top"><p class="MsoNormal"><b><i>MPT.JAS GOUIN</i></b></p>
            <p class="MsoNormal"><b><i>Salle Polyvalente</i></b></p>
            <p class="MsoNormal"><b><i>&nbsp;&nbsp;&nbsp; 13h45&nbsp; à 15h</i></b></p>
            <p class="MsoNormal"><b><i>&nbsp;LIA/Gym
              Dynam.</i></b></p>
            <p class="MsoNormal"><b><i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; FRED</i></b></p></td>
          <td width="102" valign="top"><p class="MsoNormal"><b><i>GYM.JONQUIERE</i></b></p>
            <p class="MsoNormal"><b><i>SalleEntrainement</i></b></p>
            <p class="MsoNormal"><b><i>&nbsp; 18h30&nbsp; à&nbsp; 19h30</i></b></p>
            <p class="MsoNormal"><b><i>&nbsp;Renf.Musculaire</i></b></p>
            <p class="MsoNormal"><b><i>&nbsp;&nbsp;&nbsp; JEAN-LUC</i></b></p></td>
        </tr>
        <tr>
          <td width="20" valign="top"><p class="MsoNormal"><b><i>M</i></b></p>
            <p class="MsoNormal"><b><i>A</i></b></p>
            <p class="MsoNormal"><b><i>R</i></b></p>
            <p class="MsoNormal"><b><i>D</i></b></p>
            <p class="MsoNormal"><b><i>I</i></b></p>
            <p class="MsoNormal">&nbsp;</p></td>
          <td width="97" valign="top"><p class="MsoNormal"><b><i>MPT.JAS GOUIN</i></b></p>
            <p class="MsoNormal"><b><i>Salle Polyvalente</i></b></p>
            <p class="MsoNormal"><b><i>&nbsp;&nbsp;&nbsp; 10h&nbsp; à&nbsp; 11h</i></b></p>
            <p class="MsoNormal"><b><i>Latino-Training</i></b></p>
            <p class="MsoNormal"><b><i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; JIMMY</i></b></p></td>
          <td width="108" valign="top"><p class="MsoNormal"><b><i>MPT.JAS GOUIN</i></b></p>
            <p class="MsoNormal"><b><i>Salle Polyvalente</i></b></p>
            <p class="MsoNormal"><b><i>&nbsp;&nbsp;14h&nbsp; à&nbsp; 15h30</i></b></p>
            <p class="MsoNormal"><b><i>Renf.Musculaire</i></b></p>
            <p class="MsoNormal"><b><i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; FRED</i></b></p></td>
          <td width="102" valign="top"><p class="MsoNormal"><b><i>GYM.JONQUIERE</i></b></p>
            <p class="MsoNormal"><b><i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</i></b></p>
            <p class="MsoNormal"><b><i>&nbsp; 18h30&nbsp; à 20h00</i></b></p>
            <p class="MsoNormal"><b><i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Latino- <br />
              Training</i></b></p>
            <p class="MsoNormal"><b><i>&nbsp;&nbsp;&nbsp;&nbsp; </i></b></p>
            <p class="MsoNormal"><b><i> JIMMY</i></b></p></td>
        </tr>
        <tr>
          <td width="20" valign="top"><p class="MsoNormal"><b><i>M</i></b></p>
            <p class="MsoNormal"><b><i>E</i></b></p>
            <p class="MsoNormal"><b><i>R</i></b></p>
            <p class="MsoNormal"><b><i>C</i></b></p>
            <p class="MsoNormal"><b><i>R</i></b></p>
            <p class="MsoNormal"><b><i>E</i></b></p>
            <p class="MsoNormal"><b><i>D</i></b></p>
            <p class="MsoNormal"><b><i>I</i></b></p></td>
          <td width="97" valign="top">&nbsp;</td>
          <td width="108" valign="top"><p class="MsoNormal"><b><i>MPT.JAS GOUIN</i></b></p>
            <p class="MsoNormal"><b><i>Salle Polyvalente</i></b></p>
            <p class="MsoNormal"><b><i>&nbsp; 18h&nbsp; à&nbsp; 19h30</i></b></p>
            <p class="MsoNormal"><b><i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a href="/gymnastique/hip-hop.php">HIP-HOP</a></i></b></p>
            <p class="MsoNormal"><b><i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; JIMMY</i></b></p></td>
          <td width="102" valign="top"><p class="MsoNormal"><b><i>GYM.JONQUIERE</i></b></p>
            <p class="MsoNormal"><b><i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</i></b></p>
            <p class="MsoNormal"><b><i>&nbsp;18h30&nbsp; à&nbsp; 19h30</i></b></p>
            <p class="MsoNormal"><b><i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; STEP</i></b><b><i>/LIA</i></b></p>
            <p class="MsoNormal"><b><i>AUDREY/KARYNE</i></b></p></td>
        </tr>
        <tr>
          <td width="20" valign="top"><p class="MsoNormal"><b><i>J</i></b></p>
            <p class="MsoNormal"><b><i>E</i></b></p>
            <p class="MsoNormal"><b><i>U</i></b></p>
            <p class="MsoNormal"><b><i>D</i></b></p>
            <p class="MsoNormal"><b><i>I</i></b></p></td>
          <td width="97" valign="top"><p class="MsoNormal"><b><i>MPT.JAS GOUIN</i></b></p>
            <p class="MsoNormal"><b><i>Salle Polyvalente</i></b></p>
            <p class="MsoNormal"><b><i>&nbsp;&nbsp;&nbsp;&nbsp; 10h&nbsp; à&nbsp; 11h</i></b></p>
            <p class="MsoNormal"><b><i>&nbsp;Renf.Musculaire</i></b></p>
            <p class="MsoNormal"><b><i>&nbsp;&nbsp;&nbsp; CHRISTINE</i></b></p></td>
          <td width="108" valign="top"><p class="MsoNormal"><b><i>MPT.JAS GOUIN</i></b></p>
            <p class="MsoNormal"><b><i>Salle Polyvalente</i></b></p>
            <p class="MsoNormal"><b><i>&nbsp;&nbsp;&nbsp; 13h45&nbsp; à 15h</i></b></p>
            <p class="MsoNormal"><b><i>&nbsp;LIA/Gym
              Dynam.</i></b></p>
            <p class="MsoNormal"><b><i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; FRED</i></b></p></td>
          <td width="102" valign="top"><p class="MsoNormal"><b><i>GYM.JONQUIERE</i></b></p>
            <p class="MsoNormal"><b><i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;Salle E</i></b></p>
            <p class="MsoNormal"><b><i>&nbsp;&nbsp; 18h30&nbsp; à 20h</i></b></p>
            <p class="MsoNormal"><b><i>&nbsp;Renf.Musculaire</i></b></p>
            <p class="MsoNormal"><b><i>&nbsp;&nbsp;&nbsp;&nbsp; Stretching</i></b></p>
            <p class="MsoNormal"><b><i>&nbsp;&nbsp;&nbsp;&nbsp; JEAN-LUC</i></b></p></td>
        </tr>
        <tr>
          <td valign="top"><p class="MsoNormal"><b><i>V</i></b></p>
              <p class="MsoNormal"><b><i>E</i></b></p>
            <p class="MsoNormal"><b><i>N</i></b></p>
            <p class="MsoNormal"><b><i>D</i></b></p>
            <p class="MsoNormal"><b><i>R</i></b></p>
            <p class="MsoNormal"><b><i>E</i></b></p>
            <p class="MsoNormal"><b><i>D</i></b></p>
            <p class="MsoNormal"><b><i>I</i></b></p></td>
          <td valign="top"><p class="MsoNormal"><b><i>MPT.JAS GOUIN</i></b></p>
              <p class="MsoNormal"><b><i>Salle Polyvalente</i></b></p>
            <p class="MsoNormal"><b><i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 10h&nbsp; à 11h</i></b></p>
            <p class="MsoNormal"><b><i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a href="/gymnastique/zumba.php">ZUMBA</a></i></b></p>
            <p class="MsoNormal"><b><i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; CHRISTINE</i></b></p></td>
          <td valign="top"><p class="MsoNormal"><b><i>MPT.JAS GOUIN</i></b></p>
              <p class="MsoNormal"><b><i>&nbsp;Salle
                de Danse</i></b></p>
            <p class="MsoNormal"><b><i>&nbsp;&nbsp; 14h&nbsp; à 15h30</i></b></p>
            <p class="MsoNormal"><b><i>&nbsp;GYM
              DETENTE</i></b></p>
            <p class="MsoNormal"><b><i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ELENA</i></b></p></td>
          <td valign="top"><p class="MsoNormal"><b><i>GYM.JONQUIERE</i></b></p>
              <p class="MsoNormal"><b><i>SalleEntrainement</i></b></p>
            <p class="MsoNormal"><b><i>&nbsp; 18h30&nbsp; à 19h30</i></b></p>
            <p class="MsoNormal"><b><i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a href="/gymnastique/zumba.php">ZUMBA</a></i></b></p>
            <p class="MsoNormal"><b><i>&nbsp;&nbsp; CHRISTINE</i></b></p></td>
        </tr>
        <tr>
          <td width="20" valign="top"><p class="MsoNormal"><b><i>S</i></b></p>
            <p class="MsoNormal"><strong><em>A</em></strong></p>
            <p class="MsoNormal"><em><strong>M</strong></em></p>
            <p class="MsoNormal"><em><strong>E</strong></em></p>
            <p class="MsoNormal"><em><strong>D</strong></em></p>
            <p class="MsoNormal"><b><i>I</i></b></p></td>
          <td width="97" valign="top"><p class="MsoNormal"><b><i>GYM.JONQUIERE</i></b></p>
            <p class="MsoNormal"><b><i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 10h&nbsp; à 12h</i></b></p>
            <p class="MsoNormal"><b><i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="/gymnastique/hip-hop.php">HIP-HOP</a></i></b></p>
            <p class="MsoNormal"><b><i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; JIMMY</i></b></p></td>
          <td width="108" valign="top"><p class="MsoNormal">&nbsp;</p>
            </td>
          <td width="102" valign="top"><p class="MsoNormal">&nbsp;</p>
            </td>
        </tr>
      </table>
      </div>
      <!--  FIN TABLE 1 -->
      <hr />
      <div id="cours2">
      <div align="center">
        <p><b><i><span style='font-size: 14pt; font-family: &quot;Times New Roman&quot;'>COURS MIXTE LOISIR ENFANTS, JEUNES ET ADOS 2011-2012</span></i></b></p>
        <p><b><i></span><span class="Style1">1 COTISATION    =   TOUS LES COURS MÊME ÂGE</span></i></b> </p>
      </div>
      
      <!--  TABLE 2  -->
      <table width="468" border="0" align="center" class="cours">
        <tr>
          <td width="21" valign="top"><p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>M</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>A</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>R</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>D</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>I</span></i></b></p></td>
          <td width="133" valign="top"><p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>GYM.ROQUETTE</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Gde
              Salle</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>&nbsp;&nbsp;&nbsp; 17h&nbsp; à&nbsp; 18h</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>1ere G.R&nbsp; 6/ 8ans</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; CELINE</span></i></b></p></td>
          <td width="142" valign="top">&nbsp;</td>
          <td width="152" valign="top"><p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>GYM.JONQUIERE</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Salle A</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;17h15&nbsp; à&nbsp; 18h</span></i></b><b><i><span style="font-size:10.0pt;font-family:Arial;  color:black;">15</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><u><span
  style='font-size:8.0pt;font-family:Arial;  color:black;'>Notion</span></u></i></b><b><i><span style='font-size:8.0pt;font-family:
  Arial;color:black;
  '> <a href="/gymnastique/hip-hop.php">HIP-HOP</a>&lt; 10 ans</span></i></b><b><i><span
  style='font-size:9.0pt;font-family:Arial;  color:black;'> </span></i></b><b><i><span style='font-size:10.0pt;font-family:Arial;
  color:black;
  '>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; JIMMY</span></i></b></p></td>
        </tr>
        <tr>
          <td width="21" rowspan="3" valign="top"><p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>M</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>E</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>R</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>C</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>R</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>E</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>D</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>I</span></i></b></p></td>
          <td width="133" valign="top"><p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>GYM.JONQUIERE</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>&nbsp;&nbsp;&nbsp; 9h30&nbsp; à&nbsp; 10h30</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>&nbsp;Eveil Gymnique</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 4 /
              5 ans</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; JEAN-LUC</span></i></b></p></td>
          <td width="142" valign="top"><p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>GYM.JONQUIERE</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>&nbsp; 10h45&nbsp; à&nbsp; 11h45</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>Ecole Gym&nbsp; 6/7ans</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;</span></i></b><b><i><span
  style='font-size:9.0pt;font-family:Arial;  color:black;'>niveau&nbsp;&nbsp; 1</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; JEAN-LUC</span></i></b></p></td>
          <td width="152" valign="top"><p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>GYM.JONQUIERE</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>&nbsp;&nbsp;&nbsp; 14H&nbsp; à&nbsp; 16H</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>Ecole Gym 8/10ans</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:9.0pt;font-family:Arial;  color:black;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; niveau&nbsp;&nbsp; 2</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; JEAN-LUC</span></i></b></p></td>
        </tr>
        <tr>
          <td width="133" valign="top"><p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>&nbsp; MPT.JAS GOUIN</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Salle Danse</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>&nbsp;&nbsp;&nbsp; 9h30&nbsp; à&nbsp; 10h30</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><span class="SpellE"><b><i><u><span
  style='font-size:8.0pt;font-family:Arial;  color:black;'>Début.</span></u></i></b><b><i><span style='font-size:8.0pt;font-family:
  Arial;color:black;
  '><a href="/gymnastique/hip-hop.php">HIP-HOP</a></span></i></b></span><b><i><span
  style='font-size:8.0pt;font-family:Arial;  color:black;'> 6/10 ans</span></i></b></p>
            <p align="center" class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>JIMMY</span></i></b></p></td>
          <td width="142" valign="top"><p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>MPT.JAS GOUIN </span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>&nbsp;&nbsp;&nbsp;&nbsp; Salle
              Danse</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>&nbsp;&nbsp;&nbsp; 10h45&nbsp; à&nbsp; 11h45</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><u><span
  style='font-size:9.0pt;font-family:Arial;  color:black;'>Baby </span></u></i></b><span class="SpellE"><b><i><span style='font-size:
  9.0pt;font-family:Arial;color:black;'>Hip.Hop</span></i></b></span> <b><i><span style='font-size:8.0pt;font-family:Arial;
  color:black;
  '>4/5ans</span></i></b></p>
            <p align="center" class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>JIMMY</span></i></b></p></td>
          <td width="152" valign="top"><p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>&nbsp; MPT.JAS GOUIN</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>&nbsp;Salle Polyvalente</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>&nbsp;&nbsp;&nbsp;&nbsp; 18h&nbsp; à&nbsp; 19h30</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'><a href="/gymnastique/hip-hop.php">HIP-HOP</a> + </span></i></b><b><i><span style='font-size:8.0pt;font-family:
  Arial;color:black;
  '>de 13 ans</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></i></b></p>
            <p align="center" class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>J</span></i></b><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>IMMY</span></i></b></p>
            </td>
        </tr>
        <tr>
          <td width="133" valign="top"><p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>GYM. JONQUIERE</span></i></b><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>&nbsp;&nbsp;</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>&nbsp; &nbsp;16h30&nbsp; à 17h30</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><span class="SpellE"><b><i><span
  style='font-size:9.0pt;font-family:Arial;  color:black;'>Modern’Dance/Step</span></i></b></span><b><i><span style='font-size:9.0pt;
  font-family:Arial;  color:black;'>&nbsp; 7/10ans</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>AUDREY/ KARINE</span></i></b></p></td>
          <td width="142" valign="top"><p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>GYM.JONQUIERE</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>&nbsp; 17h30&nbsp; à 18h30</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><span class="SpellE"><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>Modern’Dance/Ste</span></i></b><b><i><span style='font-size:9.0pt;
  font-family:Arial;  color:black;'>p</span></i></b></span></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>À partir de 11ans</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>AUDREY/ KARINE</span></i></b></p></td>
          <td width="152" valign="top">&nbsp;</td>
        </tr>
        <tr>
          <td width="21" valign="top"><p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:9.0pt;font-family:Arial;  color:black;'>J</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:9.0pt;font-family:Arial;  color:black;'>E</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:9.0pt;font-family:Arial;  color:black;'>U</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:9.0pt;font-family:Arial;  color:black;'>D</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:9.0pt;font-family:Arial;  color:black;'>I</span></i></b></p></td>
          <td width="133" valign="top"><p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>GYM.ROQUETTE</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Gd. Salle</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 17h&nbsp; à 18h</span></i></b></p>
            <p align="center" class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>&nbsp;1ere G.R&nbsp;&nbsp;&nbsp; </span></i></b></p>
            <p align="center" class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'> 6/8 ans</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;CELINE</span></i></b></p></td>
          <td width="142" valign="top">&nbsp;</td>
          <td width="152" valign="top"><p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>GYM.JONQUIERE</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></i></b></p>
            <p align="center" class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>17h&nbsp; à 18h</span></i></b></p>
            <p align="center" class="MsoNormal" style='vertical-align:baseline'><b><i><u><span
  style='font-size:8.0pt;font-family:Arial;  color:black;'>Inter</span></u></i></b><b><i><span style='font-size:8.0pt;font-family:
  Arial;color:black;
  '> <a href="/gymnastique/hip-hop.php">HIP-HOP</a> &lt; 12 ans</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></i></b></p>
            <p align="center" class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>JIMMY</span></i></b></p></td>
        </tr>
        <tr>
          <td width="21" valign="top"><p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:9.0pt;font-family:Arial;  color:black;'>S</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:9.0pt;font-family:Arial;  color:black;'>A</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:9.0pt;font-family:Arial;  color:black;'>M</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:9.0pt;font-family:Arial;  color:black;'>E</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:9.0pt;font-family:Arial;  color:black;'>D</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:9.0pt;font-family:Arial;  color:black;'>I</span></i></b></p></td>
          <td width="133" valign="top"><p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>GYM.JONQUIERE</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>&nbsp; 10h00&nbsp; à 11h00</span></i></b></p>
            <p align="center" class="MsoNormal" style='vertical-align:baseline'><span class="SpellE"> <b><i><span style='font-size:8.0pt;font-family:
  Arial;color:black;
  '><a href="/gymnastique/hip-hop.php">HIP-HOP</a></span></i></b></span><b><i><span
  style='font-size:8.0pt;font-family:Arial;  color:black;'> Notion &lt;10 ans</span></i></b></p>
            <p align="center" class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>JIMMY</span></i></b></p></td>
          <td width="142" valign="top"><p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>GYM.JONQUIERE</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:10.0pt;font-family:Arial;  color:black;'>&nbsp; 10h30&nbsp; à 11h30</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><span class="SpellE"><b><i><span
  style='font-size:9.0pt;font-family:Arial;  color:black;'>Parents-Bébé</span></i></b></span><b><i><span style='font-size:9.0pt;
  font-family:Arial;  color:black;'> 2/3 ans</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-size:9.0pt;font-family:Arial;  color:black;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; SENNY</span></i></b></p></td>
          <td width="152" valign="top">&nbsp;</td>
        </tr>
      </table>
      </div>
      <!--  FIN TABLE 2 -->
      
      <hr />
      <div id="cours3">
      <div align="center">
        <p><b><i><span style='font-size: 14pt; font-family: &quot;Times New Roman&quot;'>GYMNASTIQUE RYTHMIQUE COMPETITION</span></i></b><b><i><span style="font-size: 14pt; font-family: &quot;Times New Roman&quot;"> 2011-2012</span></i></b></p>
        <p><b><i></span></i></b><b><i><span style='font-size: 9pt; font-family: &quot;Times New Roman&quot;;'>FEDERATIONFRANCAISE DE GYMNASTIQUE</span></i></b> </p>
      </div>
      <!-- TABLE 3 -->
      
      <table width="404" border="0" align="center" class="cours">
        <tr >
          <td width="23" valign="top"><p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-family:Arial;color:black;'>L</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-family:Arial;color:black;'>U</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-family:Arial;color:black;'>N</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-family:Arial;color:black;'>D</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-family:Arial;color:black;'>I</span></i></b></p></td>
          <td width="185" valign="top"><p class="MsoNormal" style='vertical-align:baseline'><span style='font-family:
  Arial;color:black;
  '>GYM.JONQUIERE</span></p>
            <p class="MsoNormal" style='vertical-align:baseline'><span style='font-family:
  Arial;color:black;
  '>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 17h&nbsp; à 18h30</span></p>
            <p class="MsoNormal" style='vertical-align:baseline'><span style='font-family:
  Arial;color:black;
  '>Division Groupe&nbsp; P.</span></p>
            <p class="MsoNormal" style='vertical-align:baseline'><span style='font-family:
  Arial;color:black;
  '>Division Critérium P</span>.</p>
            <p class="MsoNormal" style='vertical-align:baseline'>&nbsp;</p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-family:Arial;color:black;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; CELINE</span></i></b></p></td>
          <td width="180" valign="top"><p class="MsoNormal" style='vertical-align:baseline'><span style='font-family:
  Arial;color:black;
  '>GYM.JONQUIERE</span></p>
            <p class="MsoNormal" style='vertical-align:baseline'><span style='font-family:
  Arial;color:black;
  '>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 18h30&nbsp; à&nbsp; 20h</span></p>
            <p class="MsoNormal" style='vertical-align:baseline'><span style='font-family:
  Arial;color:black;
  '>Individuelle Critérium</span></p>
            <p class="MsoNormal" style='vertical-align:baseline'><span class="SpellE"><span
  style='font-family:Arial;color:black;'>Benj/Min/Cad/Jun/Sén</span></span></p>
            <p class="MsoNormal" style='vertical-align:baseline'>&nbsp;</p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-family:Arial;color:black;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; CELINE</span></i></b></p></td>
        </tr>
        <tr>
          <td width="23" valign="top"><p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-family:Arial;color:black;'>M</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-family:Arial;color:black;'>A</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-family:Arial;color:black;'>R</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-family:Arial;color:black;'>D</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-family:Arial;color:black;'>I</span></i></b></p></td>
          <td width="185" valign="top"><p class="MsoNormal" style='vertical-align:baseline'><span style='font-family:
  Arial;color:black;
  '>&nbsp; GYM. ROQUETTE</span></p>
            <p class="MsoNormal" style='vertical-align:baseline'><span style='font-family:
  Arial;color:black;
  '>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 17h&nbsp; à&nbsp; 18h</span></p>
            <p class="MsoNormal" style='vertical-align:baseline'><span style='font-family:
  Arial;color:black;
  '>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Débutantes </span></p>
            <p class="MsoNormal" style='vertical-align:baseline'><span style='font-family:
  Arial;color:black;
  '>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 6&nbsp; à&nbsp; 9 ans</span></p>
            <p class="MsoNormal" style='vertical-align:baseline'>&nbsp;</p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-family:Arial;color:black;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; CELINE</span></i></b></p></td>
          <td width="180" valign="top"><p class="MsoNormal" style='vertical-align:baseline'><span style='font-family:
  Arial;color:black;
  '>&nbsp;&nbsp; GYM. ROQUETTE</span></p>
            <p class="MsoNormal" style='vertical-align:baseline'><span style='font-family:
  Arial;color:black;
  '>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 18h&nbsp; à&nbsp; 20h</span><span style='font-family:
  Arial;color:black;
  '></span></p>
            <p class="MsoNormal" style='vertical-align:baseline'><span style='font-family:
  Arial;color:black;
  '>&nbsp;&nbsp; Toutes catégories</span></p>
            <p class="MsoNormal" style='vertical-align:baseline'><span style='font-family:
  Arial;color:black;
  '>Division Critérium 1/2/3</span></p>
            <p class="MsoNormal" style='vertical-align:baseline'>&nbsp;</p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-family:Arial;color:black;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; CELINE</span></i></b></p></td>
        </tr>
        <tr>
          <td width="23" valign="top"><p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-family:Arial;color:black;'>J</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-family:Arial;color:black;'>E</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-family:Arial;color:black;'>U</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-family:Arial;color:black;'>D</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-family:Arial;color:black;'>I</span></i></b></p></td>
          <td width="185" valign="top"><p class="MsoNormal" style='vertical-align:baseline'><span style='font-family:
  Arial;color:black;
  '>&nbsp; GYM. ROQUETTE</span></p>
            <p class="MsoNormal" style='vertical-align:baseline'><span style='font-family:
  Arial;color:black;
  '>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 17h&nbsp; à&nbsp; 18h</span></p>
            <p class="MsoNormal" style='vertical-align:baseline'><span style='font-family:
  Arial;color:black;
  '>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Débutantes</span></p>
            <p class="MsoNormal" style='vertical-align:baseline'><span style='font-family:
  Arial;color:black;
  '>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 6&nbsp; À&nbsp; 9&nbsp; ans</span></p>
            <p class="MsoNormal" style='vertical-align:baseline'>&nbsp;</p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-family:Arial;color:black;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; CELINE</span></i></b></p></td>
          <td width="180" valign="top"><p class="MsoNormal" style='vertical-align:baseline'><span style='font-family:
  Arial;color:black;
  '>&nbsp; GYM. ROQUETTE</span></p>
            <p class="MsoNormal" style='vertical-align:baseline'><span style='font-family:
  Arial;color:black;
  '>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 18h&nbsp; à&nbsp; 20h</span><span style='font-family:
  Arial;color:black;
  '></span></p>
            <p class="MsoNormal" style='vertical-align:baseline'><span style='font-family:
  Arial;color:black;
  '>&nbsp;&nbsp; Toutes catégories</span></p>
            <p class="MsoNormal" style='vertical-align:baseline'><span style='font-family:
  Arial;color:black;
  '>Division Critérium 1/2/3</span></p>
            <p class="MsoNormal" style='vertical-align:baseline'>&nbsp;</p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-family:Arial;color:black;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; CELINE</span></i></b></p></td>
        </tr>
        <tr>
          <td width="23" valign="top"><p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-family:Arial;color:black;'>V</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-family:Arial;color:black;'>E</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-family:Arial;color:black;'>N</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-family:Arial;color:black;'>D</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-family:Arial;color:black;'>R</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-family:Arial;color:black;'>E</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-family:Arial;color:black;'>D</span></i></b></p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-family:Arial;color:black;'>I</span></i></b></p></td>
          <td width="185" valign="top"><p class="MsoNormal" style='vertical-align:baseline'><span style='font-family:
  Arial;color:black;
  '>GYM.JONQUIERE</span></p>
            <p class="MsoNormal" style='vertical-align:baseline'><span style='font-family:
  Arial;color:black;
  '>&nbsp;&nbsp;&nbsp;&nbsp; 17h&nbsp; à&nbsp; 18h30</span></p>
            <p class="MsoNormal" style='vertical-align:baseline'><span style='font-family:
  Arial;color:black;
  '>Division Groupe&nbsp;&nbsp; P.&nbsp; &nbsp;</span></p>
            <p class="MsoNormal" style='vertical-align:baseline'><span style='font-family:
  Arial;color:black;
  '>Division Critérium P. </span></p>
            <p class="MsoNormal" style='vertical-align:baseline'>&nbsp;</p>
            <p class="MsoNormal" style='vertical-align:baseline'>&nbsp;</p>
            <p class="MsoNormal" style='vertical-align:baseline'>&nbsp;</p>
            <p class="MsoNormal" style='vertical-align:baseline'><span style='font-family:
  Arial;color:black;
  '>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;<b><i>CELINE</i></b><b><i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</i></b></span></p></td>
          <td width="180" valign="top"><p class="MsoNormal" style='vertical-align:baseline'><span style='font-family:
  Arial;color:black;
  '>GYM. JONQUIERE</span></p>
            <p class="MsoNormal" style='vertical-align:baseline'><span style='font-family:
  Arial;color:black;
  '>&nbsp;&nbsp;&nbsp; 18h30&nbsp; à&nbsp; 20h</span></p>
            <p class="MsoNormal" style='vertical-align:baseline'><span style='font-family:
  Arial;color:black;
  '>Individuelle Critérium</span></p>
            <p class="MsoNormal" style='vertical-align:baseline'><span class="SpellE"><span
  style='font-family:Arial;color:black;'>Benj/Min/Cad/Jun/Sén</span></span></p>
            <p class="MsoNormal" style='vertical-align:baseline'>&nbsp;</p>
            <p class="MsoNormal" style='vertical-align:baseline'>&nbsp;</p>
            <p class="MsoNormal" style='vertical-align:baseline'>&nbsp;</p>
            <p class="MsoNormal" style='vertical-align:baseline'><b><i><span
  style='font-family:Arial;color:black;'>&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;CELINE</span></i></b></p></td>
        </tr>
      </table>
      </div>
      <!--  FIN TABLE 3 -->
      <div>
        <p><br/>
        Rentrée sportive le 5 septembre 2011</p>
        <p><br/>
          ACTIVITES ANNEXES  Stages Sportifs (enfants/adultes),Soirées Convivialité,  A.M récréatives, Défis GR, Challenge Fair Play Hip - Hop</p>
      </div>
      <div class="csclear"></div>
      
    </div>
    <hr />
  </div>
  <hr />
  <?php include("divr.php");?>
  <div class="csclear"></div>
</div>
<script type="text/javascript">
$( "cours1" ).show();
$( "cours2" ).hide();
$( "cours3" ).hide();
var cours1Etat = true;
var cours2Etat = false;
var cours3Etat = false;
</script>
<!-- fin csall -->
<hr />
<?php  
include("inc/footer.php");
?>
</body>
</html>
