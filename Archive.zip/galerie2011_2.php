<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xml:lang="fr" xmlns="http://www.w3.org/1999/xhtml" lang="fr">
<head>
<title>CLUB GYMNIQUE FOSSEEN</title>
<meta name="Description" content="Site du club de gymnastique de Fos Sur Mer.">
<meta name="keywords" content="Gymnastique, GR, Gymnastique, Artistique, Rythmique, Aérobic, Hip Hop, Step, Modern dance">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="-1">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.js"></script>
<script src="galleria/galleria-1.2.3.min.js"></script>

<link rel="stylesheet" type="text/css" media="all" href="css/style.css">

<style type="text/css">
<!--
.content {color:#777;font:12px/1.4 "helvetica neue",arial,sans-serif;width:620px;margin:20px auto;}
.cred {margin-top:20px;font-size:11px;}
  /* This rule is read by Galleria to define the gallery height: */
#galleria{height:320px;}
-->
</style>
<body id="bodyHome" style="background: url('/images/fond.jpg') no-repeat scroll center top white;">
<div id="csall">
<?php include("menu.php");?>
  <div id="csleft">
    <div title="clug gymnique fosséen">
    </div>
    <hr>
    <div class="csclear"></div>
    <div id="imgGymMiddle">
      <div class="onlineeditor">
        <div><?php include("inc/imageEntete.php");?></div>
      </div>
    </div>
    <hr>
    <div id="lignesDiv">
      
      
      <hr>
      <div class="content">
        <h1>La compétition Régionale Division Critérium de Gymnastique Rythmique </h1>
        <p>Fos sur Mer 2011.</p>
        <div id="galleria"> 

<a href="/2011/fos/gymnastiqueRythmique105.jpg"> <img title="Gymnastique Rythmique Championnat Régional Division Critérium Photo 1"
alt="Gymnastique Rythmique."
src="/2011/fos/gymnastiqueRythmique105.jpg"/> </a>
<a href="/2011/fos/gymnastiqueRythmique11.jpg"> <img title="Gymnastique Rythmique Championnat Régional Division Critérium Photo 2"
alt="Gymnastique Rythmique."
src="/2011/fos/gymnastiqueRythmique11.jpg"/> </a>
<a href="/2011/fos/gymnastiqueRythmique12.jpg"> <img title="Gymnastique Rythmique Championnat Régional Division Critérium Photo 3"
alt="Gymnastique Rythmique."
src="/2011/fos/gymnastiqueRythmique12.jpg"/> </a>
<a href="/2011/fos/gymnastiqueRythmique13.jpg"> <img title="Gymnastique Rythmique Championnat Régional Division Critérium Photo 4"
alt="Gymnastique Rythmique."
src="/2011/fos/gymnastiqueRythmique13.jpg"/> </a>
<a href="/2011/fos/gymnastiqueRythmique14.jpg"> <img title="Gymnastique Rythmique Championnat Régional Division Critérium Photo 5"
alt="Gymnastique Rythmique."
src="/2011/fos/gymnastiqueRythmique14.jpg"/> </a>
<a href="/2011/fos/gymnastiqueRythmique140.jpg"> <img title="Gymnastique Rythmique Championnat Régional Division Critérium Photo 6"
alt="Gymnastique Rythmique."
src="/2011/fos/gymnastiqueRythmique140.jpg"/> </a>
<a href="/2011/fos/gymnastiqueRythmique142.jpg"> <img title="Gymnastique Rythmique Championnat Régional Division Critérium Photo 7"
alt="Gymnastique Rythmique."
src="/2011/fos/gymnastiqueRythmique142.jpg"/> </a>
<a href="/2011/fos/gymnastiqueRythmique144.jpg"> <img title="Gymnastique Rythmique Championnat Régional Division Critérium Photo 8"
alt="Gymnastique Rythmique."
src="/2011/fos/gymnastiqueRythmique144.jpg"/> </a>
<a href="/2011/fos/gymnastiqueRythmique10.jpg"> <img title="Gymnastique Rythmique Championnat Régional Division Critérium Photo 9"
alt="Gymnastique Rythmique."
src="/2011/fos/gymnastiqueRythmique10.jpg"/> </a>
<a href="/2011/fos/gymnastiqueRythmique15.jpg"> <img title="Gymnastique Rythmique Championnat Régional Division Critérium Photo 10"
alt="Gymnastique Rythmique."
src="/2011/fos/gymnastiqueRythmique15.jpg"/> </a>
<a href="/2011/fos/gymnastiqueRythmique155.jpg"> <img title="Gymnastique Rythmique Championnat Régional Division Critérium Photo 11"
alt="Gymnastique Rythmique."
src="/2011/fos/gymnastiqueRythmique155.jpg"/> </a>
<a href="/2011/fos/gymnastiqueRythmique165.jpg"> <img title="Gymnastique Rythmique Championnat Régional Division Critérium Photo 12"
alt="Gymnastique Rythmique."
src="/2011/fos/gymnastiqueRythmique165.jpg"/> </a>
<a href="/2011/fos/gymnastiqueRythmique168.jpg"> <img title="Gymnastique Rythmique Championnat Régional Division Critérium Photo 13"
alt="Gymnastique Rythmique."
src="/2011/fos/gymnastiqueRythmique168.jpg"/> </a>
<a href="/2011/fos/gymnastiqueRythmique181.jpg"> <img title="Gymnastique Rythmique Championnat Régional Division Critérium Photo 14"
alt="Gymnastique Rythmique."
src="/2011/fos/gymnastiqueRythmique181.jpg"/> </a>
<a href="/2011/fos/gymnastiqueRythmique194.jpg"> <img title="Gymnastique Rythmique Championnat Régional Division Critérium Photo 15"
alt="Gymnastique Rythmique."
src="/2011/fos/gymnastiqueRythmique194.jpg"/> </a>
<a href="/2011/fos/gymnastiqueRythmique2.jpg"> <img title="Gymnastique Rythmique Championnat Régional Division Critérium Photo 16"
alt="Gymnastique Rythmique."
src="/2011/fos/gymnastiqueRythmique2.jpg"/> </a>
<a href="/2011/fos/gymnastiqueRythmique200.jpg"> <img title="Gymnastique Rythmique Championnat Régional Division Critérium Photo 17"
alt="Gymnastique Rythmique."
src="/2011/fos/gymnastiqueRythmique200.jpg"/> </a>
<a href="/2011/fos/gymnastiqueRythmique2b.jpg"> <img title="Gymnastique Rythmique Championnat Régional Division Critérium Photo 18"
alt="Gymnastique Rythmique."
src="/2011/fos/gymnastiqueRythmique2b.jpg"/> </a>
<a href="/2011/fos/gymnastiqueRythmique4.jpg"> <img title="Gymnastique Rythmique Championnat Régional Division Critérium Photo 19"
alt="Gymnastique Rythmique."
src="/2011/fos/gymnastiqueRythmique4.jpg"/> </a>
<a href="/2011/fos/gymnastiqueRythmique43.jpg"> <img title="Gymnastique Rythmique Championnat Régional Division Critérium Photo 20"
alt="Gymnastique Rythmique."
src="/2011/fos/gymnastiqueRythmique43.jpg"/> </a>
<a href="/2011/fos/gymnastiqueRythmique5.jpg"> <img title="Gymnastique Rythmique Championnat Régional Division Critérium Photo 21"
alt="Gymnastique Rythmique."
src="/2011/fos/gymnastiqueRythmique5.jpg"/> </a>
<a href="/2011/fos/gymnastiqueRythmique6.jpg"> <img title="Gymnastique Rythmique Championnat Régional Division Critérium Photo 22"
alt="Gymnastique Rythmique."
src="/2011/fos/gymnastiqueRythmique6.jpg"/> </a>
<a href="/2011/fos/gymnastiqueRythmique7.jpg"> <img title="Gymnastique Rythmique Championnat Régional Division Critérium Photo 23"
alt="Gymnastique Rythmique."
src="/2011/fos/gymnastiqueRythmique7.jpg"/> </a>
<a href="/2011/fos/gymnastiqueRythmique71.jpg"> <img title="Gymnastique Rythmique Championnat Régional Division Critérium Photo 24"
alt="Gymnastique Rythmique."
src="/2011/fos/gymnastiqueRythmique71.jpg"/> </a>
<a href="/2011/fos/gymnastiqueRythmique75.jpg"> <img title="Gymnastique Rythmique Championnat Régional Division Critérium Photo 25"
alt="Gymnastique Rythmique."
src="/2011/fos/gymnastiqueRythmique75.jpg"/> </a>
<a href="/2011/fos/gymnastiqueRythmique79.jpg"> <img title="Gymnastique Rythmique Championnat Régional Division Critérium Photo 26"
alt="Gymnastique Rythmique."
src="/2011/fos/gymnastiqueRythmique79.jpg"/> </a>
<a href="/2011/fos/gymnastiqueRythmique8.jpg"> <img title="Gymnastique Rythmique Championnat Régional Division Critérium Photo 27"
alt="Gymnastique Rythmique."
src="/2011/fos/gymnastiqueRythmique8.jpg"/> </a>
<a href="/2011/fos/gymnastiqueRythmique80.jpg"> <img title="Gymnastique Rythmique Championnat Régional Division Critérium Photo 28"
alt="Gymnastique Rythmique."
src="/2011/fos/gymnastiqueRythmique80.jpg"/> </a>
<a href="/2011/fos/gymnastiqueRythmique84.jpg"> <img title="Gymnastique Rythmique Championnat Régional Division Critérium Photo 29"
alt="Gymnastique Rythmique."
src="/2011/fos/gymnastiqueRythmique84.jpg"/> </a>
<a href="/2011/fos/gymnastiqueRythmique9.jpg"> <img title="Gymnastique Rythmique Championnat Régional Division Critérium Photo 30"
alt="Gymnastique Rythmique."
src="/2011/fos/gymnastiqueRythmique9.jpg"/> </a>  


<!-- benevoles -->
<a href="/2011/benevoles/gymnastiqueRythmique134.jpg"> <img title="Gymnastique Rythmique Photo 1"
alt="Merci a tous les bénévoles d'avoir aidé à faire de cette manifestation un succès."
src="/2011/benevoles/gymnastiqueRythmique134.jpg"/> </a>
<a href="/2011/benevoles/gymnastiqueRythmique196.jpg"> <img title="Gymnastique Rythmique Photo 2"
alt="Merci a tous les bénévoles d'avoir aidé à faire de cette manifestation un succès."
src="/2011/benevoles/gymnastiqueRythmique196.jpg"/> </a>
<a href="/2011/benevoles/gymnastiqueRythmique49.jpg"> <img title="Gymnastique Rythmique Photo 3"
alt="Merci a tous les bénévoles d'avoir aidé à faire de cette manifestation un succès."
src="/2011/benevoles/gymnastiqueRythmique49.jpg"/> </a>
<a href="/2011/benevoles/gymnastiqueRythmique52.jpg"> <img title="Gymnastique Rythmique Photo 4"
alt="Merci a tous les bénévoles d'avoir aidé à faire de cette manifestation un succès."
src="/2011/benevoles/gymnastiqueRythmique52.jpg"/> </a>
<a href="/2011/benevoles/gymnastiqueRythmique53.jpg"> <img title="Gymnastique Rythmique Photo 5"
alt="Merci a tous les bénévoles d'avoir aidé à faire de cette manifestation un succès."
src="/2011/benevoles/gymnastiqueRythmique53.jpg"/> </a>
<a href="/2011/benevoles/gymnastiqueRythmique55.jpg"> <img title="Gymnastique Rythmique Photo 6"
alt="Merci a tous les bénévoles d'avoir aidé à faire de cette manifestation un succès."
src="/2011/benevoles/gymnastiqueRythmique55.jpg"/> </a>
<a href="/2011/benevoles/gymnastiqueRythmique58.jpg"> <img title="Gymnastique Rythmique Photo 7"
alt="Merci a tous les bénévoles d'avoir aidé à faire de cette manifestation un succès."
src="/2011/benevoles/gymnastiqueRythmique58.jpg"/> </a>
<a href="/2011/benevoles/gymnastiqueRythmique59.jpg"> <img title="Gymnastique Rythmique Photo 8"
alt="Merci a tous les bénévoles d'avoir aidé à faire de cette manifestation un succès."
src="/2011/benevoles/gymnastiqueRythmique59.jpg"/> </a>
<a href="/2011/benevoles/gymnastiqueRythmique62.jpg"> <img title="Gymnastique Rythmique Photo 9"
alt="Merci a tous les bénévoles d'avoir aidé à faire de cette manifestation un succès."
src="/2011/benevoles/gymnastiqueRythmique62.jpg"/> </a> 
 </div>
 <div>
 <br/>
 Et voici 2 vidéos (merci à Eric et Orlane ;-) )
 <br/>
 <object width="425" height="344"><param name="movie" value="http://www.youtube.com/v/RvwtCJ_2MJE?hl=fr&fs=1"></param><param name="allowFullScreen" value="true"></param><param name="allowscriptaccess" value="always"></param><embed src="http://www.youtube.com/v/RvwtCJ_2MJE?hl=fr&fs=1" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="525" height="344"></embed></object>
  <br/><br/><br/>
  <object width="425" height="344"><param name="movie" value="http://www.youtube.com/v/Hn_JDFMyRg4?hl=fr&fs=1"></param><param name="allowFullScreen" value="true"></param><param name="allowscriptaccess" value="always"></param><embed src="http://www.youtube.com/v/Hn_JDFMyRg4?hl=fr&fs=1" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="525" height="344"></embed></object>
 </div>
       
      </div>
      <div class="csclear"></div>
    </div>
    
    <hr>
    
    
  </div>
  <hr>
  <?php include("divr.php");?>
  <div class="csclear"></div>
</div>
<!-- fin csall -->
<hr>
<?php 
include("inc/footer.php");
?>
<script>

    // Load the classic theme
    Galleria.loadTheme('galleria.classic.js');
    
    // Initialize Galleria
    $('#galleria').galleria();

    </script>
</body>
</html>
