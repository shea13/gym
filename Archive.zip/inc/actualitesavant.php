
     <ul class="ulActualite">
          <li>
            <h3 style="color: black;"> <a href="javascript:void(0)"> dimanche 3 Avril 2011 </a> </h3>
            <p><strong>La comp&eacute;tition R&eacute;gionale Division Crit&eacute;rium de Gymnastique Rythmique aura lieu &agrave; Fos sur Mer le 3 avril 2011 au complexe Parsemain: <a href="http://www.ff-gym-paca.com/images/fichiers/COMPETITION/GR%20DIVISION%20CRITERIUM%20FOS/Organigramme%20DC%20GR%203-04.pdf">Organigramme</a></strong></p>
          </li>
          <li>
            <h3 style="color: black;"> <a href="javascript:void(0)"> dimanche 20 mars </a> </h3>
            <p><strong>Voici l'organigramme de la prochaine &eacute;tape: la comp&eacute;tition r&eacute;gionale &agrave; Draguignan pour les DR: <a href="http://www.ff-gym-paca.com/images/fichiers/COMPETITION/GR%20DN-DF-DC1-DR%20DRAGUIGNAN/Organigramme%20DF-DC1-DR%20GR%20modif%20le%2011-03.pdf">Organigramme</a></strong>.</p>
          <li>
          <h3 style="color: black;"> <a href="javascript:void(0)"> dimanche 13 mars </a> </h3>
          <p><strong>Comp&eacute;tition d&eacute;partementale au gymnase Pesquier &agrave; Gardanne: y participent nos DG, CF et DC 2. Malheureusement, une malencontreuse entorse emp&ecirc;che nos DC4 Benjamine de participer.  <a href="http://www.bouchesdurhone-ffgym.com/attachment/252996/">Vous trouverez ICI</a> l'organigramme de la comp&eacute;tition: bonne chance &agrave; toutes nos filles!!!!</strong>            </p>
          </li>
           <li>
            <h3 style="color: black;"> <a href="javascript:void(0)">  lundi 7 et mercredi 9 mars 2011</a> </h3>
            <p>Pr&eacute;sence d'un photographe 
          aux cours du gymnase de la Jonqui&egrave;re.          </li>
           <li>
            <h3 style="color: black;"> <a href="javascript:void(0)"> du 21 au 25 f&eacute;vrier 2011</a> </h3>
            <p>Des cours vous sont propos&eacute;s la 1&egrave;re semaine des vacances au gymnase de la Jonqui&egrave;re, pour seulement 3 &euro; le cours, de 18h30 &agrave; 19h30:<br />
- lundi : renforcement musculaire avec Jean Luc.<br />
- mardi: zumba  avec Christine.<br />
- mercredi: cardio box avec Seny<br />
- jeudi: latino-training avec Jimmy<br />
- vendredi: hip-hop avec Jimmy</p>
          </li>
          <li>
            <h3 style="color: black;"> <a href="javascript:void(0)"> 16 f&eacute;vrier 2011</a> </h3>
            <p>Une &eacute;valuation sanctionnant le niveau &quot;trampolino&quot; est organis&eacute;e par le club gymnique Foss&eacute;en le Mercredi 16 f&eacute;vrier 2011 au gymnase de la Jonqui&egrave;re &agrave; Fos sur Mer<br />
A cette occasion les parents peuvent assister &agrave; l'&eacute;valution de leur(s) enfant(s)<br />
Pour plus d'information contacter Jean-Luc au 06 75 11 33 67</p>
          </li>
          	<li><a href="javascript:return false;"> 4 D&eacute;cembre 2010 </a> 
              <p>T&eacute;l&eacute;thon 2010 auquel participent, entre autres, les &eacute;quipes du club gymnique foss&eacute;en</p>
          </li>
          
          <li><a href="javascript:return false;"> 27 Novembre 2010 </a> 
            <p>Apr&egrave;s-midi r&eacute;cr&eacute;ative au profit du t&eacute;l&eacute;thon avec d&eacute;monstrations au gymnase de la Jonqui&egrave;re.</p>
          </li>
        </ul>
