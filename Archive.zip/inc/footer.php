<?php

	if(!isset($bottom))
	{
		$bottom = "-1550";
	}
	if(!isset($left ))
	{
		$left = "20";
	}
?>
<!-- DEBUT FOOTER -->
<div id="mainFooter" style="float:none; position:absolute; bottom : <?php print $bottom; ?>px; left:<?php print $left; ?>px">
	<div id="contourFooter">
		<div id="footer">
			<ul id="contenuFooter">
                <li id="footer1">
					<img src="/images/faceB.png"  style="border: 0px none;"  /> <span style="vertical-align:middle;line-height:26px;height:30px;display:inline-block;" ><a href="http://www.facebook.com/pages/Club-Gymnique-fosseen/177986328909191">Facebook</a> -  </span> <span style="vertical-align:middle;line-height:26px;height:30px;display:inline-block;" > <a href="/QuiSommesNous.php"> Qui sommes nous</a>   -  </span> <span style="vertical-align:middle;line-height:26px;height:30px;display:inline-block;" ><a href="/contact.php">Contact</a> </span>
                    <br/>
                    <p style="font-size:9px; font-weight:100">CLUB GYMNIQUE FOSSEEN - Copyright &copy; 1966-<?=date("Y")?> - Tous droits r&eacute;serv&eacute;s </p>
				</li>
			</ul>
			<div class="clearBoth">&nbsp;</div>
		</div>
	</div>
<!-- FIN PIEDS FOOTER -->