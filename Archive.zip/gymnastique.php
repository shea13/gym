<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xml:lang="fr" xmlns="http://www.w3.org/1999/xhtml" lang="fr">
<head>
<title>CLUB GYMNIQUE FOSSEEN - Gymnastique à Fos sur Mer</title>
<meta name="Description" content="Site du club de gymnastique de Fos Sur Mer.">
<meta name="keywords" content="Gymnastique, GR, Gymnastique, Artistique, Rythmique, Aérobic, Hip Hop, Step, Modern dance">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="-1">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<link rel="stylesheet" type="text/css" media="all" href="css/style.css">

<body id="bodyHome" style="background: url('fond.jpg') no-repeat scroll center top white;">
<div id="csall">
<?php include("menu.php");?>
  <div id="csleft">

    <div class="menuHautHpContenu">
      <div class="menuHautHp" id="menuHautHpedito">
      </div>
    </div>
    <h1>Club Gymnique Fosséen</h1>
    <hr>
    <div class="csclear"></div>
    <div id="imageCentreHome">
      <div class="onlineeditor">
        <div class="object-"> <a href="http://metz2010.ffgym.com/" target="_blank"> <img src="entete.jpg" style="border: 0px none;" alt="" title="" height="236" width="645"></a> </div>
      </div>
    </div>
    <hr>
    <div id="ligneBlocs1">
      <div id="bloc3">
        <div class="arrondiHautTrans"></div>
        <p><strong>Gymnastique </strong></p>
        <p>6-8 ans</p>
        <div class="arrondiBasTrans"></div>
      </div>
      
      <hr>
      <div id="bloc3">
        <div class="arrondiHautTrans"></div>
        <p><strong><a href="hiphop.php">Hip Hop</a></strong></p>
        <div class="arrondiBasTrans"></div>
      </div>
      
      <hr>
      <div id="bloc3">
        <div class="arrondiHautTrans"></div>
        <p><strong><a href="gymnastiquerythmique.php">Gymnastique Rythmique</a></strong></p>
        <p>&nbsp;</p>
        <div class="arrondiBasTrans"></div>
      </div>
      
      <div class="csclear"></div>
    </div>
    
    <hr>
    
    
  </div>
  <hr>
  <?php include("divr.php"); ?>
  <div class="csclear"></div>
</div>
<!-- fin csall -->
<hr>
<div id="footer">
  <ul>
    <li class="firstFooterLI"><a href="http://www.ffgym.com/ffgym/mentions_legales">Mentions légales</a></li>
    <li><a href="http://www.ffgym.com/ffgym/pour_nous_contacter">Contact</a></li>
  </ul>
  <div class="csclear"></div>
</div>
<?php 
include("inc/footer.php");
?>
</body>
</html>
