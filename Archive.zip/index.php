<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xml:lang="fr" xmlns="http://www.w3.org/1999/xhtml" lang="fr">
<head>
<title>CLUB GYMNIQUE FOSSEEN - Gymnastique à Fos sur Mer</title>
<meta name="Description" content="Site du club de gymnastique de Fos Sur Mer.">
<meta name="keywords" content="Gymnastique, GR, Gymnastique, Artistique, Rythmique, Aérobic, Hip Hop, Step, Modern dance">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="-1">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<link rel="stylesheet" type="text/css" media="all" href="css/style.css">
<body id="bodyHome" style="background: url('/images/fond.jpg') no-repeat scroll center top white;">


        
<div id="csall">

<?php include("menu.php");?>
  <div id="csleft">
    
    <hr>
    <div class="csclear"></div>
    <div id="imgGymMiddle">
      <div class="onlineeditor">
        <div><?php include("inc/imageEntete.php");?></div>
      </div>

    </div>
    <h1>Club Gymnique Fosséen</h1>
    <hr />
    <div id="lignesDiv">
      <div class="blanc"></div>
      <h2 >Actualités de votre club de gym</h2>
      
      <p>
        <?php
		include("inc/actualites.php");
		?>
      </p>
      <div class="actuIndex">
        <p><br/><a href="archives.php">Archives</a><br/><br/></p>
        <p><strong>CLUB GYMNIQUE FOSSEEN infos pratiques : </strong></p>
        <p> INSCRIPTION: Au Siège Maison de la Mer et du Sport<br />
          jusqu’au 31 Août. Aux heures de cours dés le 6 Septembre </p>
        <p> A FOURNIR     : Certificat Médical + Bulletin d’adhésion Club + 2 Enveloppes timbrées à votre adresse + 2 Photos<br />
          ( mineurs de 6 à 18 ans ) + Règlement (espèces ou chèques )</p>
         <p> ACTIVITES ANNEXES ( non comprises dans la cotisation )<br />
          STAGES REMISE EN FORME DU 23 AOÛT AU 3 SEPTEMBRE</p>
        <p> Escapades-randos, Stages sportifs de vacances,  Après-midi Récreative, Soirées Restos, Challenge du Fair-Play Hip-Hop.</p>
      </div>
    </div>
    <hr>
  </div>
  <hr>
  <?php $pasDactualite = true; include("divr.php");?>
  <div class="csclear"></div>
</div>
<!-- fin csall -->
<hr>
<?php 
include("inc/footer.php");
?>
</body>
</html>
