<?php
// Version: 1.1; Settings

$txt['theme_thumbnail_href'] = $settings['images_url'] . '/thumbnail.gif';
$txt['theme_description'] = 'Th&egrave;me par d&eacute;faut du Forum Simple Machines.<br /><br />Remerciements &agrave; Bloc et &agrave; l\'&eacute;quipe de design.';

?>