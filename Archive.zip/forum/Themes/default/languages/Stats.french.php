<?php
// Version: 1.1; Stats

$txt[888] = 'Connexions simultan&eacute;es';

$txt['smf_stats_1'] = 'Centre de statistiques';
$txt['smf_stats_2'] = 'Statistiques g&eacute;n&eacute;rales';
$txt['smf_stats_3'] = 'Top 10 des posteurs';
$txt['smf_stats_4'] = 'Top 10 des sections';
$txt['smf_stats_5'] = 'Historique du forum (prise en compte du d&eacute;calage horaire)';
$txt['smf_stats_6'] = 'Date (aaaa/mm/jj)';
$txt['smf_stats_7'] = 'Nouveaux fils de discussion';
$txt['smf_stats_8'] = 'Nouveaux messages';
$txt['smf_stats_9'] = 'Nouveaux membres';
$txt['smf_stats_10'] = 'Pages vues';
$txt['smf_stats_11'] = 'Top 10 des fils de discussion(par r&eacute;ponses)';
$txt['smf_stats_12'] = 'Top 10 des fils de discussion (par visualisations)';
$txt['smf_stats_13'] = 'Sommaire mensuel';
$txt['smf_stats_14'] = 'Connexions simultan&eacute;es';
$txt['smf_stats_15'] = 'Top lanceurs de fils de discussion';
$txt['smf_stats_16'] = 'Plus longue connexion';
$txt['smf_stats_17'] = 'Meilleur karma';
$txt['smf_stats_18'] = 'Pire karma';
$txt['stats_more_detailed'] = 'plus de d&eacute;tails &raquo;';

$txt['average_members'] = 'Moyenne des inscriptions par jour';
$txt['average_posts'] = 'Moyenne des messages par jour';
$txt['average_topics'] = 'Moyenne des fils de discussion par jour';
$txt['average_online'] = 'Moyenne d\'utilisateurs connect&eacute;s par jour';
$txt['users_online'] = 'Membres en ligne';
$txt['gender_ratio'] = 'Ratio hommes/femmes';
$txt['users_online_today'] = 'En ligne aujourd\'hui';
$txt['num_hits'] = 'Pages vues au total';
$txt['average_hits'] = 'Pages vues en moyenne par jour';

$txt['smf_news_1'] = 'commentaire';
$txt['smf_news_2'] = 'commentaires';
$txt['smf_news_3'] = '&Eacute;crire un commentaire';
$txt['smf_news_error2'] = 'Vous ne pouvez pas sp&eacute;cifier une section interdite d\'acc&egrave;s aux invit&eacute;s.  Merci de v&eacute;rifier l\'ID de la section avant de r&eacute;essayer.';
$txt['xml_rss_desc'] = 'Informations en direct de ' . $context['forum_name'];

?>