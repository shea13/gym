<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xml:lang="fr" xmlns="http://www.w3.org/1999/xhtml" lang="fr">
<head>
<title>CLUB GYMNIQUE FOSSEEN</title>
<meta name="Description" content="Site du club de gymnastique de Fos Sur Mer.">
<meta name="keywords" content="Gymnastique, GR, Gymnastique, Artistique, Rythmique, Aérobic, <strong>hip hop</strong>, Step, Modern dance">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="-1">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">


<link rel="stylesheet" type="text/css" media="all" href="/css/style.css">


</head>
<body id="bodyHome" style="background: url('/images/fond.jpg') no-repeat scroll center top white;">
<div id="csall">
<?php include($_SERVER['DOCUMENT_ROOT']."/menu.php");?>
  <div id="csleft">
    <div title="clug gymnique fosséen">
    </div>
    <hr>
    <div class="csclear"></div>
    <div id="imgGymMiddle">
      <div class="onlineeditor">
        <div><?php include($_SERVER['DOCUMENT_ROOT']."/inc/imageEntete.php");?></div>
      </div>
    </div>
    <hr>
    <br/><br/>
    <div id="lignesDiv">
      
      
      <hr>
        <div  style="font-size:12px"><br/>
        <p>La <strong>Zumba</strong> est un programme de fitness colombien créé par Beto Perez qui s'appuie sur des rythmes et des chorégraphies inspirées des danses latines. </p>
       <br/> <p>Beto Perez, professeur de fitness colombien et également chorégraphe de nombreux artistes dont la chanteuse Shakira, invente la <strong>Zumba</strong> dans un de ses cous en improvisant des mouvements d'aerobics sur des musiques latines.</p>
        <p>Dans les années 90, la <strong>Zumba</strong> gagne l'Amérique du nord et séduit plus d'un million d'adeptes.</p>
        <p>Depuis, l'engouement pour ce sport s'est répandu dans plus de 75 pays.</p>
        <br/>
<p>Chez nous, c'est la pétillante Christine, animatrice diplômée qui vous fera &quot;zumber&quot; sur les rythmes endiablés de salsa, merengue, cumbia, reggaeton, calypso, soca, samba, cha-cha-cha, hip hop, africaines, indiennes... </p>
<br/>
      </div>
      
      <div class="csclear"></div>
    </div>
    
    <hr>
    
    
  </div>
  <hr>
  <?php include($_SERVER['DOCUMENT_ROOT']."/divr.php");?>
  <div class="csclear"></div>
</div>
<!-- fin csall -->
<hr>
<?php 
include($_SERVER['DOCUMENT_ROOT']."/inc/footer.php");
?>
</body>
</html>
