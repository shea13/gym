<?
include($_SERVER["DOCUMENT_ROOT"]."/inc/bdd/parametres.inc");
include($_SERVER["DOCUMENT_ROOT"]."/inc/technical/article.inc");
$aResult = parametres::queryDb("SELECT S * from articles WHERE etat!=-1  ORDER BY dateDebutEvenement DESC, indice DESC LIMIT 1");
print "test 1 '" .$aResult."'";
?>