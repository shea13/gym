<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xml:lang="fr" xmlns="http://www.w3.org/1999/xhtml" lang="fr">
<head>
<title>CLUB GYMNIQUE FOSSEEN - Gymnastique à Fos sur Mer</title>
<meta name="Description" content="Site du club de gymnastique de Fos Sur Mer.">
<meta name="keywords" content="Gymnastique, GR, Gymnastique, Artistique, Rythmique, Aérobic, Hip Hop, Step, Modern dance">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="-1">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">


<link rel="stylesheet" type="text/css" media="all" href="css/style.css">
<body id="bodyHome" style="background: url('/images/fond.jpg') no-repeat scroll center top white;">
<div id="csall">
<?php include("menu.php");?>
  <div id="csleft">

    <hr>
    <div class="csclear"></div>
    <div id="imgGymMiddle">
      <div class="onlineeditor">
        <div><?php include("inc/imageEntete.php");?></div>
      </div> 

    </div>
    <h1>&nbsp;</h1>
    <hr>
    <div id="lignesDiv">
      
      
      <hr>
      <div>
        <table width="100%">
        <tr>
          <th align="left">TARIFS ANNUELS 2011/2012 - Licence et Assurance comprises</th>
        </tr>
        <tr>
          <th align="left">&nbsp;</th>
        </tr>
        <tr>
          <td><strong>2 à 5 ans</strong></td>
          <td>75&euro;</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td><strong>6 à 15 ans et séniors</strong></td>
          <td>102&euro;</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td><strong>Compétition</strong></td>
          <td>112&euro;</td>
        </tr>
        <tr>
          <th align="left">&nbsp;</th>
        </tr>
        <tr>
          <td><strong>15 à 60 ans</strong></td>
          <td>112&euro;</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td colspan="2"> *  Réduction de 10 euros pour une deuxième inscription</td>
        </tr>
        <tr>
          <td colspan="2">*  BIENVENUE Chèque Attitude 13 du C.G, AEVF, C.E.</td>
        </tr>
         <tr>
          <td colspan="2"><p>&nbsp;</p>
            <p>INSCRIPTION: </p>
            <p>A la Maison de la Mer et du Sport, à partir du 16 Août de 15h à 17h. </p>
            <p>Ou bien, dès la rentrée aux heures de cours.</p>
            <p>&nbsp;</p>
            <p> A FOURNIR     :  </p>
            <p>Certificat médical + Bulletin d'adhésion du club + <br />
              Droit à l’image pour les – 18 ans + 2 enveloppes timbrées à votre adresse<br />
            + Règlement (espèces ou chèques) </p></td>
        </tr>
      </table>
      </div>
      
      <div class="csclear"></div>
    </div>
    
    <hr>
    
    
  </div>
  <hr>
  <?php include("divr.php");?>
  <div class="csclear"></div>
</div>
<!-- fin csall -->
<hr>
<?php 
include("inc/footer.php");
?>
</body>
</html>
