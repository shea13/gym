<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xml:lang="fr" xmlns="http://www.w3.org/1999/xhtml" lang="fr">
<head>
<title>CLUB GYMNIQUE FOSSEEN</title>
<meta name="Description" content="Site du club de gymnastique de Fos Sur Mer.">
<meta name="keywords" content="Gymnastique, GR, Gymnastique, Artistique, Rythmique, Aérobic, Hip Hop, Step, Modern dance">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="-1">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">


<link rel="stylesheet" type="text/css" media="all" href="css/style.css">

<link rel="stylesheet" type="text/css" media="screen" href="css/reset.css" />
<link rel="stylesheet" type="text/css" media="screen" href="css/960.css" />
<link rel="stylesheet" type="text/css" media="screen" href="css/main.css" />
<script type="text/javascript" src="js/jquery-1.4.4.min.js"></script>
<script type="text/javascript" src="js/demo.js"></script>
</head>
<body id="bodyHome" style="background: url('/images/fond.jpg') no-repeat scroll center top white;">
<div id="csall">
<?php include("menu.php");?>
  <div id="csleft">
    <div title="clug gymnique fosséen">
    </div>
    <hr>
    <div class="csclear"></div>
    <div id="imgGymMiddle">
      <div class="onlineeditor">
        <div><?php include("inc/imageEntete.php");?></div>
      </div>
    </div>
    <hr>
    <br/><br/>
    <div id="lignesDiv">
      
      
      <hr>
        <div  style="font-size:12px"><br/><br/>
        	
            <a href="galerie2011_6.php"> Téléthon 2011  : Journée démonstration en faveur du Téléthon</a><br/><br/>
        	<a href="galerie2011_5.php"> Gymnastique  : Compétition de GAM-GAF 5 juin 2011</a><br/><br/>
        	<a href="galerie2011_4.php"> HIP HOP : Challenge fair-play Fos sur Mer 28 mai 2011</a><br/><br/>
        	<a href="galerie2011_3.php"> Gymnastique Rythmique : Compétition départementale Gardanne 13 mars 2011</a><br/><br/>
            <a href="galerie2011_2.php"> Gymnastique Rythmique : Compétition Régionale Division Critérium dimanche 3 avril 2011 (Photos et vidéos)</a><br/><br/>
       		<a href="galerie2010.php">Téléthon 2010 </a><br/><br/>
             </div>
      
      <div class="csclear"></div>
    </div>
    
    <hr>
    
    
  </div>
  <hr>
  <?php include("divr.php");?>
  <div class="csclear"></div>
</div>
<!-- fin csall -->
<hr>
<?php 
include("inc/footer.php");
?>
</body>
</html>
