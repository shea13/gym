<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xml:lang="fr" xmlns="http://www.w3.org/1999/xhtml" lang="fr">
<head>
<title>CLUB GYMNIQUE FOSSEEN - Gymnastique à Fos sur Mer</title>
<meta name="Description" content="Site du club de gymnastique de Fos Sur Mer.">
<meta name="keywords" content="Gymnastique, GR, Gymnastique, Artistique, Rythmique, Aérobic, Hip Hop, Step, Modern dance">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="-1">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">


<link rel="stylesheet" type="text/css" media="all" href="css/style.css">

<body id="bodyHome" style="background: url('/images/fond.jpg') no-repeat scroll center top white;">
<div id="csall">
<?php include("menu.php");?>
  <div id="csleft">

    <hr>
    <div class="csclear"></div>
    <div id="imgGymMiddle">
      <div class="onlineeditor">
        <div><?php include($_SERVER['DOCUMENT_ROOT']."/inc/imageEntete.php");?></div>
      </div>
    </div>
    <h1>Club Gymnique Fosséen</h1>
    <hr>
    <!-- <h2 class="titre2 violet">
        <strong>Sites</strong>
      </h2>-->
      <br/>
      <div class="p">&nbsp;</div>
    <div id="lignesDiv">
      
     
      <hr>
      <div>
        <table width="100%">
         <tr>
          <td>Site Officiel de Fos sur mer</td>
          <td> <a href="http://www.fos-sur-mer.fr/" target="_blank">Fos sur mer</a></td>
        </tr>
         <tr>
          <td>Un site d'information sur la gymnastique rythmique </td>
          <td> <a href="http://www.bodychou.com/" target="_blank">Bodychou</a></td>
        </tr>
        
      </table>
      </div>
      
      <div class="csclear"></div>
    </div>
    
    <hr>
    
    
  </div>
  <hr>
  <?php include("divr.php");?>
  <div class="csclear"></div>
</div>
<!-- fin csall -->
<hr>
<?php 
include("inc/footer.php");
?>
</body>
</html>
