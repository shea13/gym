<?php 
header("Location: veloSoirInside.php?t=".time());
exit;
?>