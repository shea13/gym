<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xml:lang="fr" xmlns="http://www.w3.org/1999/xhtml" lang="fr">
<head>
<title>CLUB GYMNIQUE FOSSEEN</title>
<meta name="Description" content="Site du club de gymnastique de Fos Sur Mer.">
<meta name="keywords" content="Gymnastique, GR, Gymnastique, Artistique, Rythmique, Aérobic, Hip Hop, Step, Modern dance">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="-1">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">


<link rel="stylesheet" type="text/css" media="all" href="css/style.css">
<body id="bodyHome" style="background: url('/images/fond.jpg') no-repeat scroll center top white;">
<div id="csall">
<?php include("menu.php");?>
  <div id="csleft">

    <hr>
    <div class="csclear"></div>
    <div id="imgGymMiddle">
      <div class="onlineeditor">
        <div><?php include("inc/imageEntete.php");?></div>
      </div>
    </div>
    <h1>Club Gymnique Fosséen</h1>
    <hr>
    <div id="lignesDiv">
      
      
      <hr>
      <div>
        <table width="100%">
        <tr>
          <td><strong>Par Tél </strong></td>
          <td>06.75.11.33.67</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>06 42 44 28 18</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>06 61 97 11 57 </td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>06 83 75 42 49</td>
        </tr>
        <tr>
          <th align="left">Par email</th>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td><a href="mailto:clubgymniquefosseen@yahoo.fr">clubgymniquefosseen@yahoo.fr</a></td>
        </tr>
        <tr>
          <th align="left">Siège Social</th>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>MAISON DE LA MER ET DU SPORT</td>
        </tr>
        
        <tr>
          <td>&nbsp;</td>
          <td>Avenue des sables d'or</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>BP 505</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>13895 FOS SUR MER CEDEX</td>
        </tr>
      </table>
      </div>
      
      <div class="csclear"></div>
    </div>
    
    <hr>
    
    
  </div>
  <hr>
  <?php include("divr.php");?>
  <div class="csclear"></div>
</div>
<!-- fin csall -->
<hr>
<?php 
include("inc/footer.php");
?>
</body>
</html>
